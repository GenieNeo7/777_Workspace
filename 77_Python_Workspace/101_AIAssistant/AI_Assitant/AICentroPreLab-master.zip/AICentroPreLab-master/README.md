# AICentroPreLab
* KTDS AICentro를 사용하기 위한 PreLab과정의 소스코드 입니다. 
## 1.AICentro
## 2.PythonLibrary
## 3.ModelEvaluation
## 4.MachineLearning
## 5.DataPreprocessing
## 6.KerasBasic
## 7.NLP


